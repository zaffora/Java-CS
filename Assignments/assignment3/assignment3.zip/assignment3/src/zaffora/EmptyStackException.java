package zaffora;

public class EmptyStackException extends RuntimeException
{
    public EmptyStackException(String e)
    {
        super(e);
    }
}
