package zaffora;

public class Main {

    public static void main(String[] args) {

        PokedexDriverCSV pokedex = new PokedexDriverCSV();

        pokedex.showDeck();

    }
}
